﻿#################### Starting message/reply of bot ###########################################

greet = ['''"Healing takes time, and asking for help is a courageous step." 
Tamak foundation can help you!
let us know your concern.''', '''"you can overcome everything that you feel can destroy."
we at Tamak foundation can help you.
You just need to connect us''', '''"What mental health needs is more sunlight, more candor, and more unashamed conversation."
You can connect us "Tamak Foundation"
Let me know your concern.''']

bot_inputs = ["We understood that you are facing some stress, Don't worry, We will help you",
              "Suicide is something do by Cowards, Let's fight together the problem",
              "Depression is what we focus too much on some issue, There will be always hope even if your brain says no, Lets fight together",
              "Dont worry, we will help you to overcome anxiety", "Mental_stress/depression"]

################################### Chat Log Files path  ##########################################
# log_path = "log_files/"  ########## For chats Logs
# data_files = "log_files/"  ######## For CSV files

############################### Below are the list of words to be given to bot to restart/start the conversation again #####################

greet_list = ["hi", "hello", "hey", "hiii", "heya", "hi how are you", "hii", "hows u", "what you can do for me",
              "triggerit", 'ok', 'okay', 'okie']