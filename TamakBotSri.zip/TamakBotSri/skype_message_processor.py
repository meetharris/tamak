__AUTHOR__ = "kethavath srinivas"

"""
This python file will process the user message received from skype
and dispatch corresponding message for the next action.
"""
from datetime import datetime
import svcmodel
import os
global ver
import random
import sys
import re
import config
import config_file_processor
from session import ConversationSessionManager
import pandas as pd

bot = config_file_processor.chatbot()
import spacy
from pprint import pprint
import re
import mysql.connector

log_path = "log_files/"  ########## For chats Logs
data_files = "log_files/"
if not os.path.exists(log_path):
    os.makedirs(log_path)

def PhoneNumberCheck(text):
    result = []
    PhnNumCheck = re.compile(r'''
        (\d{3}|\(\d{3}\))    #first three-digit
        (\s|-|\.)?           #separator or space
        (\d{3}|\(\d{3}\))    #second three-digits
        (\s|-|\.)?           #separator or space
        (\d{4}|\(\d{4}\))    #last four-digits
    ''', re.VERBOSE)
    for num in PhnNumCheck.findall(text):
        result.append(num[0] + num[2] + num[4])
    if len(result) > 0:
        return result[0]
    else:
        return None


def EmailCheck(text):
    result = []
    emailCheck = re.compile(r'''
        [a-zA-Z0-9.+_-]+  #username
        @                 #@ character
        [a-zA-Z0-9.+_-]+  #domain name
        \.                #first .(dot) 
        [a-zA-Z]          #domain type like-- com
        \.?               #second .(dot) for domains like co.in
        [a-zA-Z]*         #second part of domain type like 'in' in  co.in 
    ''', re.VERBOSE)

    for emails in emailCheck.findall(text):
        result.append(emails)
    if len(result) > 0:
        return result[0]
    else:
        return None
nlp = spacy.load("en_core_web_lg")

problems = ['depression', 'depressed', 'depress', 'feeling unwell', 'loneliness', 'lonely', 'stress', 'stressing', 'stressed', 'anxiety',
            'illness','sad', 'mentally', 'ill', 'unwell']


def dateEtract(text, date1, date2):
    date = date1
    if date2 != '':
        date_space = date1 + ' ' + date2
        date_and = date1 + ' and ' + date2
        if date_space in text:
            date = date_space
        elif date_and in text:
            date = date_and
    return date


def processDate(current_session, text, date):
    question = current_session.res_sess
    if question is None:
        question = 'last question is none'

    if (
            'age is ' + date in text or date + ' old' in text or 'old' in date or ' age' in question) and current_session.age in [
        None, "Not interested"]:
        current_session.age = date
        return True
    if (
            'past ' + date in text or 'last ' + date in text or 'from ' + date in text or 'since ' + date in text or 'past' in date or 'last' in date or "experiencing the problem" in question) and current_session.period in [
        None, "Not interested"]:
        current_session.period = date
        return True
    else:
        return False


stopwords = ['i', 'me', 'myself', 'we', 'ours', 'ourselves', 'you', 'yourself', 'yourselves', 'he', 'him', 'himself',
             'she', 'her', 'hers', 'herself', 'it', 'itself', 'they', 'them', 'theirs', 'themselves', 'what', 'who',
             'whom', 's', 't', 'don', "don't", "won't"]

# -------------------SESSION CREATION-----------------------

conversation_sessions = ConversationSessionManager()

# ------------------------------------------FILES PATH----------------------------------------


# v_start=config.version_start_range
# v_end=config.version_end_range
# a1 = config.start_of_the_opportunity_number
# b1 = config.length_of_opportunity_number


### Method for writing the chat logs of user to call for every user message and append to the file created
def logs_user(filename, username, text):
    with open(filename, "a", encoding='utf-8') as myfile:  # ,encoding='utf-8'
        myfile.write(
            "[" + str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + "]" + username + "\n" + str(text) + "\n\n")


## Method for writing the chat logs of Bot
def logs_bot(filename, t):
    with open(filename, "a") as myfile:
        myfile.write("[" + str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + "]" + "BOT" + "\n" + str(t) + "\n\n")


def check_if_reworks_are_none(current_session):
    # and current_session.c_handle is None  and current_session.s_handle is None   and current_session.d_handle is None
    if current_session.sdc_ver is None and current_session.dc_ver is None and current_session.sc_ver is None and current_session.sd_ver is None and current_session.c_handle is None and current_session.s_handle is None and current_session.d_handle is None:
        a = True
    else:
        a = False
    return a


### Method for dell business logic of chat flow which will be called in dell_bot_api file for every message from user from skype
def inp(text, sess_id):
    # try:

    sessionId = sess_id
    t = None
    m = None
    current_session = conversation_sessions.get(sessionId)
    if current_session is None:
        print("its new session")
        current_session = conversation_sessions.new(sessionId)
        # current_session.filesession = str(username) + "_" + str(current_session.id)
        current_session.date_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')+'@@'+datetime.now().strftime('%Y-%m-%d_%H_%M_%S')
        logslist = os.listdir('log_files')
        for file in logslist[:-20]:
            os.remove(log_path+ file)
        # current_session.emailid = email
    filename = log_path + "Tamak_Bot_Logs" + "_" + str(
        current_session.date_time.split('@@')[1]) + ".txt"  # To create the file name with user email id and current time with .txt extension
    print("previous response", current_session.res_sess)
    # print(bot.get_response(text.lower()).confidence, "bot confidence for the current statement")
    logs_user(filename, "User", text)
    if current_session.chat is None:
        current_session.chat = text
    else:
        current_session.chat = current_session.chat + text
    print(text, "above")
    text = ' '.join(text.split('\n'))
    print(text, "bellow")
    text = text.lower().replace("not well", "unwell")
    text = text.lower().replace("feeling not good", "feeling unwell")
    text = text.lower().replace("not feeling good", "feeling unwell")
    text = text.lower().replace("not feeling well", "feeling unwell")
    text = text.lower().replace("not good", "unwell")
    text = text.replace(" one ", " 1 ")
    text = text.replace(" two ", " 2 ")
    text = text.replace(" three ", " 3 ")
    text = text.replace(" four ", " 4 ")
    text = text.replace(" five ", " 5 ")
    text = text.replace(" six ", " 6 ")
    text = text.replace(" seven ", " 7 ")
    text = text.replace(" eight ", " 8 ")
    text = text.replace(" nine ", " 9 ")
    text = text.replace(" ten ", " 10 ")
    text = text.lower().replace("'", '').replace("?", '  ').replace('  ', ' ').replace("=", ' ').replace(" tamakbot ",
                                                                                                         '  ').replace(
        ' tamak ', ' ').replace(" bot ", ' ')
    text = text.replace("im ", 'i am ').replace(" wanna ", ' want to ').replace('ill ', 'i will ').replace('wont ',
                                                                                                           "dont want ").replace(
        ' ok ', ' okay ')
    text = re.sub(" +", " ", text)
    print(text, "after cleaning")
    intent = svcmodel.predict(text)
    date1 = ''
    date2 = ''
    date3 = ''
    date4 = ''
    text = re.sub(r'[^A-Za-z0-9\s\\.\@]', ' ', text).lower()
    text = re.sub('\s+', ' ', text).strip()
    doc = nlp(text)
    print('Sentence:')
    pprint(doc)
    print('Entities:')

    # for i in result['entities']:
    #     if i['entity'] in ['days', 'months', 'weeks', 'years'] and i['confidence'] > 0.60:
    #         current_session.period = i['value'] + " " + i['entity']
    #     elif current_session.problem is None and i['entity'] == 'problem' and i['confidence'] > 0.60:
    #         current_session.problem = i['value']
    #         current_session.have_problem = "Yes"
    #         current_session.to_appened = 'Yes'
    #     elif i['entity'] == 'age' and i['confidence'] > 0.60:
    #         current_session.age = i['value']
    #
    #     elif i['entity'] == 'UserName' and i['confidence'] >= 0.58:
    #         if current_session.UserName is None:
    #             current_session.UserName = i['value']
    #         # elif current_session.UserName==i['value']:
    #         #     t="We have just taken your details, Please try on some one behalf"

    if current_session.phone_number is None:
        phone = PhoneNumberCheck(text)
        current_session.phone_number = phone
        print('phone:', phone)
    if current_session.email is None:
        email = EmailCheck(text)
        current_session.email = email
        print('email:', email)

    if current_session.problem is None:
        text_split = text.split(' ')
        for i, word in enumerate(text_split[:-1]):
            text_split.append(text_split[i] + ' ' + text_split[i + 1])
        for i in text_split:
            if i in problems:
                print(i)
                problem = i
                current_session.problem = problem
                current_session.have_problem = "Yes"
                current_session.to_appened = 'Yes'
                break

    NUM = [token.lemma_ for token in doc if token.pos_ == "NUM"]
    if current_session.res_sess is not None and "know your age" in current_session.res_sess and current_session.age is None:
        if len(NUM) > 0:
            current_session.age = " {} years".format(NUM[0])
    print('NUM:', NUM)

    for entity in doc.ents:
        print(entity.text, entity.label_)
        if entity.label_ == 'GPE' and current_session.city is None:
            cityName = entity.text
            current_session.city = cityName
        if entity.label_ == 'PERSON' and current_session.UserName is None:
            personName = entity.text
            current_session.UserName = personName

        if entity.label_ == 'DATE' and date1 == '':
            digit = entity.text
            if digit.isdigit() and len(digit) > 5:
                pass
            else:
                date1 = entity.text
        elif entity.label_ == 'DATE' and date2 == '':
            digit = entity.text
            if digit.isdigit() and len(digit) > 5:
                pass
            else:
                date2 = entity.text
        elif entity.label_ == 'DATE' and date3 == '':
            digit = entity.text
            if digit.isdigit() and len(digit) > 5:
                pass
            else:
                date3 = entity.text
        elif entity.label_ == 'DATE' and date4 == '':
            digit = entity.text
            if digit.isdigit() and len(digit) > 5:
                pass
            else:
                date4 = entity.text
            date4 = entity.text

    if current_session.res_sess == "Please tell us your full name" and current_session.UserName is None:
        nouns = [chunk.text for chunk in doc.noun_chunks]

        if (intent['confidence'] > 0.6 and intent['name'] == "notoinfo") or (
                "dont want" in text.lower() or "dont share" in text.lower() or "never share" in text.lower() or "not interested" in text.lower()):
            m = "It's okay, No Problem"
            current_session.UserName = "Not interested"
        elif text.lower().replace(' ', '').isalpha():
            # nounsNew = [noun for noun in nouns if noun not in stopwords]
            # if len(nounsNew) > 0:
            #     current_session.UserName = ' '.join(word for word in nounsNew).capitalize()
            # else:
            current_session.UserName = text.capitalize()
        else:
            t = "Please provide valid name"

    if current_session.age is None or current_session.period is None:
        date = dateEtract(text, date1, date2)
        processDate(current_session, text, date)
    if current_session.age is None or current_session.period is None:
        date = dateEtract(text, date2, date3)
        processDate(current_session, text, date)
    if current_session.age is None or current_session.period is None:
        date = dateEtract(text, date3, date4)
        processDate(current_session, text, date)

    if current_session.res_sess is not None and "know your age" in current_session.res_sess and current_session.age is None:
        if re.findall('[0-9]{1,2}', text.lower()) and len(re.findall('[0-9]{1,2}', text.lower())) == 1:
            current_session.age = re.findall('[0-9]{1,2}', text.lower())[0]
        #     current_session.age=re.findall('[0-9]{1,2}', text.lower())[0]
        elif (intent['confidence'] > 0.6 and intent['name'] == "notoinfo") or (
                "dont want" in text.lower() or "dont share" in text.lower() or "never share" in text.lower() or "not interested" in text.lower()):
            m = "It's okay, No Problem"
            current_session.age = "Not interested"
        else:
            t = "Please provide valid age"

    if current_session.res_sess == "Tell us the city you are residing in" and current_session.city is None:
        if (
                "dont want" in text.lower() or "dont share" in text.lower() or "never share" in text.lower() or "not interested" in text.lower()) and current_session.count is None:
            current_session.count = 1
            t = "We never share your address/data with anyone. Certainly, we are here to help you and you can share with us"
        elif (
                "dont want" in text.lower() or "dont share" in text.lower() or "never share" in text.lower() or "not interested" in text.lower()) and current_session.count == 1:
            m = "It's okay, No Problem"
            current_session.count = None
            current_session.city = "Not interested"
        elif (intent['confidence'] > 0.7 and intent['name'] == "notoinfo") or (
                'not share' in text.lower() or 'not tell' in text.lower() or 'not interested' in text.lower(),
                "dont want" in text.lower().replace("'",
                                                    '') or 'dont share' in text.lower() or 'not interested' in text.lower() or 'not share' in text.lower() or 'not interested' in text.lower() or 'no interest' in text.lower() or 'never share' in text.lower()):
            m = "It's okay, No Problem"
            current_session.city = "Not interested"
            # print(intent_classifier,"intents")
        elif current_session.city is None:
            current_session.city = text.capitalize()

    if (
            current_session.phone_number is None or current_session.phone_number == "Not interested") and current_session.email is None and current_session.res_sess == "Since We don't have your contact number to reach you, please share your email ID to contact you.":
        if re.findall('[0-9]{10}', text.lower()) or re.findall('\S+@\S+', text):
            # current_session.res_sess = t
            if re.findall('[0-9]{10}', text.lower()):
                current_session.phone_number = re.findall('[0-9]{10}', text.lower())[0]
                print(re.findall('[0-9]{10}', text.lower())[0], "phone number")
            if re.findall('\S+@\S+', text):
                current_session.email = re.findall('\S+@\S+', text)[0]

        elif (intent['confidence'] > 0.7 and intent['name'] == "notoinfo") or (
                'not share' in text.lower() or 'not tell' in text.lower() or 'not interested' in text.lower(),
                "dont want" in text.lower().replace("'",
                                                    '') or 'dont share' in text.lower() or 'not interested' in text.lower() or 'not share' in text.lower() or 'not interested' in text.lower() or 'no interest' in text.lower() or 'never share' in text.lower()):
            if current_session.count is None:
                current_session.count = 1
            else:
                current_session.count = current_session.count + 1
            if current_session.count == 2:
                t = "Seems you dont want to share your info, It's okay, However, you can always feel free to reach us for personal assistance at tamakfoundation@gmail.com"
                current_session.count = None
                current_session.res_sess = None
            else:
                t = "It's necessary for us to have your contact info to help you, Please trust us and share your contact number or email Id"
        else:
            t = "Please provide valid email id or number"

    if current_session.res_sess == "Share us your contact number":
        if re.findall('[0-9]{10}', text.lower()):
            print(re.findall('[0-9]{10}', text.lower())[0], "phone number")
            # current_session.res_sess = t
            current_session.phone_number = re.findall('[0-9]{10}', text.lower())[0]
            current_session.To_confirm = "yes"
        elif re.findall('[0-9]{4,9}', text.lower()):
            t = "Number is not valid."
        elif ("dont want" in text.lower().replace("'",
                                                  '') or 'dont share' in text.lower() or 'not interested' in text.lower() or 'no interest' in text.lower() or 'never share' in text.lower()) and current_session.count is None:
            t = "Understood your concern. But, We are here to help you and you can trust us"
            current_session.validation = "yes"
            current_session.count = 1
        elif ('not share' in text.lower() or 'not tell' in text.lower() or 'not interested' in text.lower(),
              "dont want" in text.lower().replace("'",
                                                  '') or 'dont share' in text.lower() or 'not interested' in text.lower() or 'not share' in text.lower() or 'not interested' in text.lower() or 'no interest' in text.lower() or 'never share' in text.lower()) and current_session.count == 1:
            m = "It's Okay, We value your opinion"
            current_session.count = None
            current_session.phone_number = "Not interested"
        elif (intent['confidence'] > 0.7 and intent['name'] == "notoinfo") or (
                'not share' in text.lower() or 'not tell' in text.lower() or 'not interested' in text.lower()):
            m = "It's okay, No Problem"
            current_session.phone_number = "Not interested"
        else:
            t = "Please provide valid phone number"
            current_session.validation = "yes"
    print(current_session.phone_number, current_session.age, current_session.city, current_session.UserName,
          current_session.Final, current_session.period, current_session.problem, current_session.to_appened,
          "above entities")

    if current_session.res_sess == "Please share the few details with us.\nHow long you are experiencing the problem":
        if re.findall("[0-9]{1,2}",
                      text.lower()) or "week" in text.lower() or "year" in text.lower() or "yr" in text.lower() or "month" in text.lower() or "day" in text.lower():
            if "week" in text.lower():
                if current_session.period is None:
                    current_session.period = re.findall("[0-9]{1,2}", text.lower())[0] + ' weeks'
                else:
                    current_session.period = current_session.period
            elif "month" in text.lower():
                if current_session.period is None:
                    current_session.period = re.findall("[0-9]{1,2}", text.lower())[0] + ' months'
                else:
                    current_session.period = current_session.period
            elif "day" in text.lower():
                if current_session.period is None:
                    current_session.period = re.findall("[0-9]{1,2}", text.lower())[0] + ' days'
                else:
                    current_session.period = current_session.period
            elif "year" in text.lower() or 'yr' in text.lower():
                if current_session.period is None:
                    current_session.period = re.findall("[0-9]{1,2}", text.lower())[0] + ' years'
                else:
                    current_session.period = current_session.period
            elif "hour" in text.lower() or 'hr' in text.lower():
                if current_session.period is None:
                    current_session.period = re.findall("[0-9]{1,2}", text.lower())[0] + ' hours'
                else:
                    current_session.period = current_session.period
            else:
                current_session.period = re.findall("[0-9]{1,2}", text.lower())[0]
                t = "Please confirm if the above value is years/months/weeks/days/hours"
        else:
            t = "Please provide a valid period"

    print(t, "value of t")
    if text.lower() == "triggerit" and current_session.To_confirm is None:
        # #logs_user(filename, username, text)
        current_session.have_problem = None
        current_session.id = None
        current_session.id_string = None
        current_session.uuid = None
        current_session.problem_Description = None
        current_session.UserName = None
        current_session.period = None
        current_session.problem = None
        current_session.phone_number = None
        current_session.city = None
        current_session.age = None
        current_session.To_confirm = None
        t = random.choices(config.greet)[0]  # + str(username) + "
        current_session.Final = None
        current_session.validation = None
        current_session.count = None
        current_session.res_sess = t
        current_session.to_appened = None
        # print(bot.get_response(text.lower()).confidence,"confidence")


    elif current_session.problem is None and current_session.res_sess == "Are you going through depression or have any mental stress?":
        if re.search('no', text.lower()) and 'not' not in text.lower():
            t = "Good to hear. You can always reach us for any mental health related issues."
            current_session.To_confirm = "yes"
            current_session.email = None
            current_session.have_problem = 'No'
            # conversation_sessions.delet_session(current_session)
            # current_session.res_sess = None
            current_session.have_problem = None
            current_session.problem_Description = None
            current_session.UserName = None
            current_session.period = None
            current_session.problem = None
            current_session.phone_number = None
            current_session.city = None
            current_session.age = None
            current_session.To_confirm = None
            current_session.Final = None
            current_session.validation = None
            current_session.count = None
            current_session.res_sess = None
            current_session.to_appened = None
            # current_session.id_string = None
            # current_session.id = None
            # current_session.uuid = None


        elif re.findall('yes', text.lower()):
            t = "You should not worry about it. Can you share what problem you are facing?"
            current_session.res_sess = t
            current_session.have_problem = 'Yes'
            current_session.problem_Description = "Mental_stress/depression"
            current_session.problem = "Mental_stress/depression"
        else:
            t = "Please confirm saying yes or no"



    elif t is None and m is None and current_session.res_sess not in config.bot_inputs and bot.get_response(
            text.lower().replace("'", '').replace('?', '').replace('.', '').replace(",", ' ')).confidence > 0.89:
        try:
            t = bot.get_response(text.lower()).text
            # if current_session.problem is None and g in config.bot_inputs:
            #     pass
            # # current_session.res_sess=t
            # else:
            #     t=g
            print("bot response", t)
            if t in config.bot_inputs and current_session.problem_Description is None:
                current_session.problem = 'Depression/stress/anxiety'
                current_session.res_sess = t

        except:
            t = "There is some issue while processing your request, Please try after some time"
    # elif current_session.problem is None and current_session.To_confirm is None: #and current_session.To_confirm is None:
    #     t="Are you going through depression or have any mental stress?"
    #     current_session.res_sess = t

    elif current_session.period is None and current_session.problem is not None:  # and current_session.res_sess is not None and current_session.res_sess.replace("'",'') in config.bot_inputs or current_session.res_sess == "You should not worry about it. Can you share what problem you are facing?":
        t = "Please share the few details with us.\nHow long you are experiencing the problem"
        current_session.res_sess = t
        # current_session.problem_Description = text.lower()

    elif t is None and current_session.UserName is None and current_session.problem is not None:  # and current_session.res_sess=="Please share the few details with us.\nHow long you are experiencing the problem":
        t = "Please tell us your full name"
        current_session.res_sess = t

    elif t is None and current_session.age is None and current_session.problem is not None:  # and current_session.res_sess=="Okay, Please tell us your full name":
        t = "Please let us know your age"
        current_session.res_sess = t
    elif t is None and current_session.phone_number is None and current_session.problem is not None:
        t = "Share us your contact number"
        current_session.res_sess = t

    elif t is None and current_session.city is None and current_session.problem is not None:
        t = "Tell us the city you are residing in"
        current_session.res_sess = t

    elif ((
                  current_session.phone_number is not None and current_session.phone_number != "Not interested") or current_session.email is not None) and current_session.age is not None \
            and current_session.city is not None and current_session.UserName is not None and current_session.Final is None \
            and current_session.period and current_session.problem is not None:
        t = "Thanks " + current_session.UserName.capitalize() + " for sharing your details. We will connect you as early as possible and will help you overcome your problems."
        current_session.chat = current_session.chat + t
        # import mysql.connector

        chat_time = current_session.date_time.split('@@')[0]

        try:
            mydb = mysql.connector.connect(
                host="148.72.232.176",
                user="db_Tamak",
                password="T03m0k123$",
                database="ph21167207529_"
            )

            mycursor = mydb.cursor()
            print("chat_time:", chat_time)
            sql = "INSERT INTO dishaChats (chat, UserName, Email, Age, Phone_Number, City, Period,chatid, Problem,chat_time) VALUES (%s,%s,%s, %s, %s, %s, %s, %s, %s, %s)"
            val = (current_session.chat, current_session.UserName, current_session.email, current_session.age,
                   current_session.phone_number,
                   current_session.city, current_session.period, current_session.id, current_session.problem, chat_time)
            mycursor.execute(sql, val)

            mydb.commit()
        except Exception as e:
            print('Database error:', str(e))
        print('Yes written')

        current_session.res_sess = t
        current_session.Final = "Yes"
        current_session.have_problem = None
        current_session.problem_Description = None
        current_session.UserName = None
        current_session.period = None
        current_session.problem = None
        current_session.phone_number = None
        current_session.city = None
        current_session.age = None
        current_session.To_confirm = None
        current_session.Final = None
        current_session.validation = None
        current_session.count = None
        current_session.res_sess = None
        current_session.to_appened = None
        current_session.id_string = None
        current_session.id = None
        current_session.uuid = None
        current_session.email = None
        # current_session.chat=None

        logs_bot(filename, t)
        return t, sess_id

    elif t is None and (
            current_session.phone_number is not None and current_session.phone_number == "Not interested") and current_session.age is not None \
            and current_session.city is not None and current_session.UserName is not None and current_session.Final is None \
            and current_session.period and current_session.problem is not None and current_session.email is None:
        t = "Since We don't have your contact number to reach you, please share your email ID to contact you."
        current_session.res_sess = t
    # elif current_session.res_sess=="Thanks"+current_session.UserName+" for sharing your details. We will connect you as early as possible and will help you overcome your problems." and (re.findall("thank",text.lower()) or re.findall("tq",text.lower())):
    #     t="You are most welcome"
    #     current_session.res_sess = t
    #     current_session.To_confirm="yes"
    # elif current_session.res_sess=="Thanks"+current_session.UserName+" for sharing your details. We will connect you as early as possible and will help you overcome your problems." and text.lower() in ['ok','okay','okie']:
    #     t="Bye, Have a great day"
    #     current_session.res_sess = t
    #     current_session.To_confirm="yes"
    #     print("current_session",current_session.phone_number,current_session.UserName,current_session.have_problem,
    #           current_session.problem_Description,current_session.city,current_session.period,current_session.id)

    elif text.lower() in ['thanks', 'thanks much', 'thanks a lot', 'thank you very much', 'tq', 'tq very much',
                          'okay thanks', 'okay thank you very much', 'okay tq', 'okay tq very much',
                          'tqs a lot', 'tqs', 'thanks bye', 'bye thanks', 'okay bye', 'bye', 'thank you bye',
                          'bye thank you', 'bye then', 'okay then bye']:
        t = "No Worries"
    elif text.lower() in ['thanks bye', 'bye thanks', 'okay bye', 'bye', 'thank you bye', 'bye thank you', 'bye then',
                          'okay then bye']:
        t = "Bye... Have a great day!"
    elif text.lower() in ['okay', 'okies', 'yeah', 'hmm', 'hmmm', 'hm', 'cool', 'great', 'okay cool', 'okay great']:
        t = "yup"
    elif intent['name'] == "thankyou" and intent['confidence'] > 0.83:
        t = random.choice(["No Worries", "You are welcome", "No Problem", "You are most welcome"])
        # print(t,)
    else:
        if current_session.problem is None:
            t = random.choices(config.greet)[0]
        elif t is None:
            t = "Didn't get you. Could you please re-phrase"
            with open("tamak's_exceptions.txt", "a") as myfile:
                myfile.write(
                    "[" + str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) + "]" + "USER" + "\n" + str(text) + "\n\n")

    if current_session.problem is not None and current_session.to_appened == 'Yes':
        print("in yes")
        if current_session.UserName is not None:
            t = "Hi " + current_session.UserName.capitalize() + ', We understood that you have the problem of ' + current_session.problem + ". Don't worry, we are here for you.\n Meanwhile, " + t
        elif current_session.UserName is not None and current_session.problem == 'unwell':
            t = "Hi " + current_session.UserName.capitalize() + ', We understood that you are feeling ' + current_session.problem + ". Don't worry, we are here for you.\n Meanwhile, " + t
        elif current_session.UserName is None and current_session.problem == 'unwell':
            t = "We understood that you are not feeling good" + ". Don't worry, we are here for you.\n Meanwhile, " + t
        elif current_session.UserName is None and current_session.problem == 'sad':
            t = "Don't worry, We are here to fill your life with joy and happiness.\n Meanwhile, " + t

        else:
            t = 'We understood that you have the problem of ' + current_session.problem + ". Don't worry, we are here for you.\n Meanwhile, " + t
        current_session.to_appened = None
    if current_session is not None and current_session.validation == 'yes':
        current_session.validation = 'No'
    if m is not None and t != "Didn't get you. Could you please re-phrase":
        t = m + '. ' + t
    # except:
    #     import config_file_processor
    #
    #     bot.get_response(text.lower().replace("'", '').replace('?', '').replace('.', '').replace(",", ' ')).confidence
    logs_bot(filename, t)
    print(current_session.phone_number, current_session.age, current_session.city, current_session.UserName,
          current_session.Final, current_session.period, current_session.problem, current_session.to_appened,
          "session info")
    print(intent, "intent")
    print(intent['confidence'], "confidence")
    print("session info:")
    current_session.chat = current_session.chat + t + "\n"
    print('current_session.res_sess:', current_session.res_sess)
    # print("chat total", current_session.chat)
    print('current_session.phone_number:', current_session.phone_number)
    print('current_session.email:', current_session.email)
    print('current_session.age:', current_session.age)
    print('current_session.city:', current_session.city)
    print('current_session.UserName:', current_session.UserName)
    print('current_session.Final:', current_session.Final)
    print('current_session.period:', current_session.period)
    print('current_session.problem:', current_session.problem)
    print(' current_session.to_appened:', current_session.to_appened)

    return t, sess_id


if __name__ == '__main__':
    print('Hello How may I help you?')
    text = input('Enter:')
    data, session_id = inp(text, 'hhi9s99s')
    while True:
        text = input(data + ':')
        data, session_id = inp(text, 'hhi9s99s')
        print(data)
