import sys
from flask import Flask, jsonify
import json, requests
from flask_cors import CORS, cross_origin
from flask import json
from flask.globals import request
# import os
# import email_notification as en
from datetime import datetime
import skype_message_processor
import re
import traceback
from flask import Blueprint, request, jsonify, send_from_directory, render_template
import os
import socket

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_STATIC = os.path.join(APP_ROOT, 'static')
# --------------------------------------------------------------------------------------------

app = Flask(__name__)
CORS(app)


# Method to stop the Flask_API before changes are done in config file, calling this in start_bot.BAT file
def shutdown_server():
    func = request.environ.get('werkzeug.server.shutdown')
    if func is None:
        raise RuntimeError('Not running with the Werkzeug Server')
    func()

    # # ----------------------------FAQ Classifier Called--------------------------------------------------------------------------
    def blueprint(self, on_new_message):
        job_portal = Blueprint(
            'job_portal', __name__, template_folder='templates',
            static_url_path='static', static_folder='static'
        )

        @job_portal.route('/status', methods=['GET', 'POST'])
        # @sh.wrapper()
        def health():
            return jsonify({"status": "ok"})

        @job_portal.route('/js/<path:path>')
        def send_js(path):
            return send_from_directory(os.path.join(APP_STATIC, 'js'), path)

        @job_portal.route('/css/<path:path>')
        def send_css(path):
            return send_from_directory(os.path.join(APP_STATIC, 'css'), path)

        @job_portal.route('/images/<path:path>')
        def send_images(path):
            return send_from_directory(os.path.join(APP_STATIC, 'images'), path)

        @job_portal.route("/dialog", methods=['GET', 'POST'])
        # @sh.wrapper()
        def chat_dialog():
            return render_template('chatbox/chat.html')


@app.route('/tamak-bot', methods=['POST', 'GET'])
@cross_origin()
def GetFAQ():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})
    data = request.json
    print(data)
    if 'message' not in data:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": 'Expecting key as data'})
    try:
        statement = data['message']
        print(statement)
        statement = statement.replace(',', " ")
        statement = re.sub("\.+", ".", statement)
        statement = statement.replace('. ', " ")
        print("data receiving from gui bot", data)
    except Exception as e:
        print("there is some issue")
        return json.dumps({"DATA": None,
                           })
    try:

        data, session_id = skype_message_processor.inp(re.sub(" +", " ", statement.strip()), data[
            'sender'])  # , data['sess_id'],data["email_id"],data["username"],data["Session_start_time"],data['Hit_count'])#data['Hit_count']
        print("------------------------------------------------------------------------------")
    except Exception as e:
        # print(os.getcwd())
        k = traceback.format_tb(e.__traceback__)
        with open("Input_exceptions.txt", "a", encoding='utf-8') as myfile:  # ,encoding='utf-8'
            myfile.write(
                "[" + str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + "]" + '(' + str(
                    data["sender"]) + ')' + "\n" + "User_Input: " + str(statement) + '\n' + 'Error_Details: ' + str(
                    e) + '\n' + "Traceback_details: " + str(k) + "\n\n")
        # print(en.send_email(e,statement,data["username"],data["email_id"]))
        print(e)
        return json.dumps({'Status": "ERROR", "DATA": None, "Reason": "Internal server error'})
    print(session_id, "sessionid")
    print(type(session_id), "sessionid")
    print(data, "data")
    return json.dumps([{"Status": "SUCCESS", "text": data, "recipient_id": session_id}])


@app.route('/shutdown', methods=['GET'])
def shutdown():
    shutdown_server()
    return 'Restarting the DELL BOT...'


# ---------------------------------------------------------------------------------------------------
try:
    host_name = socket.gethostname()
    host_ip = str(socket.gethostbyname(host_name))
    print("Hostname :  ", host_name)
    print("IP : ", host_ip)
except:
    print("Unable to get Hostname and IP")
    host_name = 'localhost'
    host_ip = '127.0.0.1'


def startAPIs():
    try:
        app.run(host_ip, port=(5004), debug=False, threaded=False)
        app.run()
    except Exception as e:
        raise ("APIs not started Exception (startAPIs ) at : " + host_ip + ":" + str(
            5004) + " due to :" + str(
            e))


if __name__ == '__main__':
    startAPIs()
