import requests

url = 'http://192.168.2.204:5004/tamak-bot'
while True:
    text = input('Enter:')
    data = {"message": text,
            "sender": "h55i"
            }
    x = requests.post(url, json=data)
    print(x.text)
